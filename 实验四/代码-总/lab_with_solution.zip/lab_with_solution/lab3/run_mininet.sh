#!/bin/bash

sudo python pwospf_topo.py
