#!/bin/bash
./pox/pox.py pwospf.ofhandler pwospf.srhandler
