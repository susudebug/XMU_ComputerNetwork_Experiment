#!/bin/bash
pkill -9 sr_solution
pkill -9 sr
sudo pkill -9 python
