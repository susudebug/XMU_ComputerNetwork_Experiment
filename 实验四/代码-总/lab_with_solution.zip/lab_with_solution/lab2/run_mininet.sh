#!/bin/bash

sudo python lab2.py
